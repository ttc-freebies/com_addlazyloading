<?php
defined('_JEXEC') or die('Restricted access');

class AddlazyloadingController extends Joomla\CMS\MVC\Controller\BaseController {
  protected $default_view = 'lazy';
}
