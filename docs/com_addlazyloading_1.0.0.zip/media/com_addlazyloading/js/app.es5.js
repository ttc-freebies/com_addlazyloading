(function () {
	'use strict';

	alert('Please use a newer browser');

}());
